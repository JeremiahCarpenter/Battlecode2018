// A handy extra function we can call.
int extra_function();