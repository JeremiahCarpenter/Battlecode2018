import random
import sys
import traceback
import battlecode as bc

# Reads the Earth/Mars maps at the beginning
# Stores both maps in a readable grid
# Provides Read/Write access for other controllers to update
# May do comet tracking here as well
class MapControl:
    """This is the map control"""
    def __init__(self, gameControl):


    def InitializeEarth(self):


    def InitializeMars(self):


    def HashCoordinates(self, intX, intY):
        # Implement Code Here

        return hash

    def GetNode(self, planet, mapX, mapY):
        # Implement Code Here

        return node

    def GetRandomEarthNode(self):
        # Implement Code Here
        
        return location

    def GetRandomMarsNode(self):
        # Implement Code Here

        return marsNode

    def GetNodeEarth(self, mapX, mapY):
        # Implement Code Here

        return None