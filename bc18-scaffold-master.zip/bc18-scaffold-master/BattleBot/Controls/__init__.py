# Add imports here for controls
from Controls.BuildControl import BuildControl
from Controls.CommunicationControl import CommunicationControl
from Controls.EnemyTrackingControl import EnemyTrackingControl
from Controls.MapControl import MapControl
from Controls.PathfindingControl import PathfindingControl
from Controls.ResearchControl import ResearchControl
from Controls.StrategyControl import StrategyControl
from Controls.TargettingControl import TargettingControl
from Controls.UnitControl import UnitControl
from Controls.MissionControl import MissionControl