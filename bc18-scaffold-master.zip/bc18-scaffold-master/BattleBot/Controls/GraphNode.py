class GraphNode:
    def __init__(self, room, parent, action):
        self.room = room
        self.Parent = parent
        self.Action = action