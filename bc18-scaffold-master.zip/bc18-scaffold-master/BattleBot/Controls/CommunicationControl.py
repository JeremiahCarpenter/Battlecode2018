import random
import sys
import traceback

# Handles communication between Earth and Mars
# Public Methods for reading/writing
# Consider that messages should be as small as possible to avoid excessive processing/memory